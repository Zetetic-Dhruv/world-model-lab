LeWM resolution study — probing-validity bundle
================================================

The durable outcome of a multi-day study: a four-gate validity protocol for
probing learned representations without fooling yourself. Most of the "results"
were measurement artifacts and are retracted; the protocol is what survived.

START HERE
----------
  docs/METHODS_URS.md   — the protocol in URS form (A,M,R,T) with the
                          KK-resolution argument and the proof-witness ledger.
                          THIS IS THE ENTRY POINT.
  docs/METHODOLOGY.md   — the same four gates in plain English, with worked numbers.
  docs/V2_DESIGN.md     — the clean redo the protocol makes possible (not yet run).

THE FOUR GATES (a measured property must survive all four before it is "known")
  Gate 0  Convergence       — measure trajectories, not snapshots; compare convergence-matched.
  Gate 1  Estimator geometry — probe vs KSG; anti-collapse regularizers corrupt k-NN MI.
  Gate 2  Split leakage      — split by trajectory/episode, never by frame.
  Gate 3  Power & baseline   — raw-input ceiling (DPI); enough held-out groups; normalize.

LAYOUT
------
  docs/        the methods paper (URS + plain), v2 design, repro README.
  scripts/     the tooling. diagnostics.py = the four-gate instruments
               (state_decoding_probe w/ GroupShuffleSplit; ksg_mi; effective_rank_pr).
               run_diagnostics.py, run_sweep.py (--keep-ckpt-epochs), plot_trajectory.py.
               train.py / eval_planning.py / env_*.py / data.py / lewm/ = the pipeline.
  results/
    trajectory_study_100ep_probe/   GPU 100-epoch study WITH the probe (img64, img128).
                                    diagnostics_epoch{4,9,19,39,69}.json + final +
                                    train_log.csv. These carry the probe + KSG numbers
                                    the gates were derived from.
    cpu_sweep_10ep_RETRACTED/       The original 10-epoch 6-resolution sweep whose
                                    "5 strong claims" were under-training artifacts.
                                    Kept for provenance; DO NOT cite its numbers.
  figures/     fig_trajectory_img64/img128/overlay.png (the convergence + frontier figs).

NOT INCLUDED (large binaries): model checkpoints (.pt) and datasets (.h5) — the GPU VM
that held them was torn down; the pipeline regenerates both from scripts/.

HONEST STATUS
-------------
  Survives all gates (true knowledge): predictive-accuracy convergence speed is
  monotone in resolution; effective rank rises over training (anti-collapse
  compliance, not quality).
  Retracted (artifacts): "rank ~12 resolution-invariant", "MI saturates 3.4-3.5",
  the frame-split sufficiency gap.
  Open (needs v2): the powered, ceiling-correct state-sufficiency gap.

Provenance: github.com/Zetetic-Dhruv/world-model-lab  (commit ac8df46 or later)
